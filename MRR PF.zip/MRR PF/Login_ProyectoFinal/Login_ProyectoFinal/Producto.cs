﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Login_ProyectoFinal
{
    class Producto
    {
		private string id;
		private string nombre;
		private string precioCompra;
		private string precioVenta;
		private string cantidad;

		public Producto() { }

		public Producto(string i, string n, string pc, string pv, string c)
		{
			id = i;
			nombre = n;
			precioCompra = pc;
			precioVenta = pv;
			cantidad = c;
		}

		public string Cantidad
		{
			get { return cantidad;; }
			set { cantidad = value; }
		}


		public string PrecioVenta
		{
			get { return precioVenta; }
			set { precioVenta = value; }
		}


		public string PrecioCompra
		{
			get { return precioCompra; }
			set { precioCompra = value; }
		}


		public string Nombre
		{
			get { return nombre; }
			set { nombre = value; }
		}


		public string Id
		{
			get { return id; }
			set { id = value; }
		}

	}
}
