﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace Login_ProyectoFinal
{
    /// <summary>
    /// Lógica de interacción para Registro.xaml
    /// </summary>
    public partial class Registro : Window
    {
        string pathName = @".\Registro_Ventas.txt";
        string pathNames = @".\Registro_Productos.txt";

        public Registro()
        {
            InitializeComponent();
        }

        private void MostrarClientes()
        {
            try
            {
                if (File.Exists(pathNames))
                {

                    StreamReader tuberiaLectura = File.OpenText(pathNames);
                    string linea = tuberiaLectura.ReadLine();
                    while (linea != null)
                    {
                        txt_datosProductos.AppendText(linea + "\r\n");
                        linea = tuberiaLectura.ReadLine();
                    }
                    tuberiaLectura.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar los clienes" + ex.Message);
            }
        }

        private void MostrarVentas()
        {
            try
            {
                if (File.Exists(pathName))
                {
                    txt_nom.Text = "";
                    txt_nit.Text = "";
                    StreamReader tuberiaLectura = File.OpenText(pathName);
                    string linea = tuberiaLectura.ReadLine();
                    while (linea != null)
                    {
                        txt_datosVentas.AppendText(linea + "\r\n");
                        linea = tuberiaLectura.ReadLine();
                    }
                    tuberiaLectura.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al mostrar los clienes" + ex.Message);
            }
        }

        private void btn_venta_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if ((File.Exists(pathName)))
                {

                    string idCliente = txt_id.Text;
                    string cliente = txt_nom.Text;
                    string nit = txt_nit.Text;
                    if (cliente != "" && idCliente != "" && nit != "")
                    {
                        if (ValidarId(idCliente))
                        {
                            StreamWriter tuberiaEscritura = File.AppendText(pathName);
                            tuberiaEscritura.WriteLine(idCliente + "," + cliente + "," + nit);
                            tuberiaEscritura.Close();
                            MessageBox.Show("Cliente grabado con exito");
                            txt_nom.Text = "";
                            txt_id.Text = "";
                            MostrarVentas();
                        }
                        else
                        {
                            MessageBox.Show("El id debe de ser unico");
                        }
                    }
                    else
                    {
                        MessageBox.Show("No se permite vacio");
                    }
                }
                else
                {
                    File.Create(pathName);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private bool ValidarId(string idCliente)
        {
            bool respuesta = true;
            string[] datosSeparados;
            StreamReader tuberiaLectura = File.OpenText(pathName);
            string linea = tuberiaLectura.ReadLine();

            while (linea != null)
            {
                datosSeparados = linea.Split(',');
                if (idCliente == datosSeparados[0])
                {
                    respuesta = false;
                    break;
                }
                linea = tuberiaLectura.ReadLine();
            }
            tuberiaLectura.Close();
            return respuesta;
        }

        private void btn_salir_Click(object sender, RoutedEventArgs e)
        {
            VentanaPrincipal principal = new VentanaPrincipal();
            this.Hide();
            principal.ShowDialog();
            this.Close();
        }
    }
}
